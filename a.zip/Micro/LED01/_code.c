void main() {
     TRISC.F0=0;
     TRISC.F1=0;
     
     while(1){
       PORTC.F0=1;
       Delay_ms(100);
       PORTC.F0=0;
       Delay_ms(100);
       
       PORTC.F1=1;
       Delay_ms(100);
       PORTC.F1=0;
       Delay_ms(100);
     }
     
}