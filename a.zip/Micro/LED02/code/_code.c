void main() {
 unsigned char i;
 TRISD =0x00;
 while(1){
 for(i=0;i<5;i++){
    PORTD=(1<<i);
    Delay_ms(100);
 }
 
 }
}