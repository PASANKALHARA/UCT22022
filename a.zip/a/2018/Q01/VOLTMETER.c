// LCD module connections
sbit LCD_RS at RB4_bit;
sbit LCD_EN at RB5_bit;
sbit LCD_D4 at RB0_bit;
sbit LCD_D5 at RB1_bit;
sbit LCD_D6 at RB2_bit;
sbit LCD_D7 at RB3_bit;

sbit LCD_RS_Direction at TRISB4_bit;
sbit LCD_EN_Direction at TRISB5_bit;
sbit LCD_D4_Direction at TRISB0_bit;
sbit LCD_D5_Direction at TRISB1_bit;
sbit LCD_D6_Direction at TRISB2_bit;
sbit LCD_D7_Direction at TRISB3_bit;

char txt[15];

// Function to convert ADC value to string
void ConvertToVoltage(unsigned int adc_value) {
    unsigned int whole, decimal;

    // Calculate voltage (0-5V range)
    // Using integer math to avoid floating point
    whole = (adc_value * 5) / 1023;    // Whole number part
    decimal = ((adc_value * 500) / 1023) % 100;  // Decimal part

    // Convert to string
    txt[0] = whole + 48;    // Convert whole number to ASCII
    txt[1] = '.';           // Decimal point
    txt[2] = (decimal / 10) + 48;  // First decimal place
    txt[3] = (decimal % 10) + 48;  // Second decimal place
    txt[4] = 0;             // String terminator
}

void main() {
    unsigned int adc_value;

    // Initialize ADC
    ADCON1 = 0x0E;        // Configure AN0 as analog
    TRISA.RA0 = 1;        // Configure AN0 pin as input
    ADCON2 = 0x92;        // Right justified, 4TAD, FOSC/32
    ADCON0 = 0x01;        // ADC ON, Channel 0

    // Initialize LCD
    Lcd_Init();
    Lcd_Cmd(_LCD_CLEAR);
    Lcd_Cmd(_LCD_CURSOR_OFF);

    // Display initial message
    Lcd_Out(1, 1, "VOLTMETER");
    Delay_ms(2000);

    while(1) {
        Lcd_Cmd(_LCD_CLEAR);

        // Read ADC and convert to voltage string
        adc_value = ADC_Read(0);
        ConvertToVoltage(adc_value);

        // Display voltage
        Lcd_Out(1, 1, "Voltage: ");
        Lcd_Out(1, 9, txt);
        Lcd_Out(1, 13, "V");

        Delay_ms(1000);
    }
}