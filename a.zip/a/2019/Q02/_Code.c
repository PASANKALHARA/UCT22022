// LED Chasing Effect for PIC16F877A
// Crystal Frequency: 8 MHz

void main() {
    unsigned char i;        // Declare 'i' as an unsigned 8-bit integer

    TRISC = 0x00;           // Configure PORTC as output (all pins of PORTC as outputs)
    PORTC = 0x00;           // Initialize PORTC to 0 (all LEDs off)

    while (1) {             // Infinite loop
        for (i = 0; i < 8; i++) {   // Loop through 8 LEDs
            PORTC = (1 << i);       // Shift a bit to turn on one LED at a time
            Delay_ms(100);         // 1-second delay (1000 milliseconds)
        }
    }
}


